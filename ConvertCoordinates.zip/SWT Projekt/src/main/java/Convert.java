import org.osgeo.proj4j.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Convert {

    public static void main(String[] args) {
        if(args.length != 2) {
            System.err.println("Please give the input and output filepath as arguments \n for example: javac Convert.java -input/file.csv -output/file.cdv");
        } else {
            List<String> lines = new ArrayList<>();
            Transformer trans = new Transformer();
            try {
                FileReader fr = new FileReader(new File(args[0]));
                BufferedReader br = new BufferedReader(fr);
                br.lines().skip(1).forEach(l -> {
                            String[] col = l.split("\t");
                            if ((!col[6].isEmpty()) && (!col[7].isEmpty())) {
                                ProjCoordinate transformed =
                                        trans.transform(Integer.valueOf(col[6]), Integer.valueOf(col[7]));
                                col[6] = String.valueOf(transformed.y);
                                col[7] = String.valueOf(transformed.x);
                                lines.add(String.join("\t", col) + "\n");
                            }
                        }
                );

                fr.close();
                br.close();

                FileWriter fw = new FileWriter(new File(args[1]));
                BufferedWriter out = new BufferedWriter(fw);
                for (String s : lines)
                    out.write(s);
                out.flush();
                out.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

}
