import org.osgeo.proj4j.*;

public class Transformer {

    private CoordinateTransformFactory ctFactory = new CoordinateTransformFactory();
    private CRSFactory csFactory = new CRSFactory();

    private String csName = "EPSG:4647";
    final String EPSG4647_PARAM = "+proj=tmerc +lat_0=0 +lon_0=9 +k=0.9996 +x_0=32500000 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs ";
    private CoordinateReferenceSystem crs = csFactory.createFromParameters(csName, EPSG4647_PARAM);

    private final String WGS84_PARAM = "+title=long/lat:WGS84 +proj=longlat +ellps=WGS84 +datum=WGS84 +units=degrees";
    private CoordinateReferenceSystem WGS84 = csFactory.createFromParameters("WGS84", WGS84_PARAM);

    private CoordinateTransform trans = ctFactory.createTransform(crs, WGS84);

    /**
     * Does the Projection from EPSG:4647 to WSG84 for an individual coordinate consisting of
     *
     * @param aN_RW "Rechtswert der geographischen Position"
     * @param aN_HW "Hochwert der geographischen Position"
     *              quotes source: https://opendata.schleswig-holstein.de/dataset/windkraftanlagen
     * @return Coordinates in WSG84 format
     */
    public ProjCoordinate transform(int aN_RW, int aN_HW) {
        ProjCoordinate p = new ProjCoordinate();
        ProjCoordinate p2 = new ProjCoordinate(); //the result of the projection will be saved here

        //assign the coordinates to be transformed
        p.x = aN_RW;
        p.y = aN_HW;

        trans.transform(p, p2);
        return p2;
    }
}
